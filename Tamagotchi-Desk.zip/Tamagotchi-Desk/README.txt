TAMAGOTCHI DESK PET
===================

What it does
- Lives in the bottom-right corner of your screen, always on top.
- Every UNREAD Gmail message that arrived TODAY drops in as a little parachute box by its house.
- When you read the email (in Gmail, on your phone, anywhere), the door opens and the box goes inside.
- Every meeting on today's Google Calendar brings a guest. The guest arrives 15 min before
  (you can change this in Settings), they play catch together, and the guest waves and walks off when the meeting ends.
- Its day follows your clock: sleeps → wakes up → breakfast → works → lunch → waters plants →
  works → plays outside → dinner → reads under a lamp → sleeps. The sky, sun and moon move with the hour.

Getting started (one time)
1. Double-click start.bat.
   - If Node.js isn't installed it will install it, then ask you to run start.bat again.
   - First launch downloads its parts (about 1 minute).
2. The settings window opens. Fill in:
   - Gmail address
   - A Google APP PASSWORD (not your normal password):
       myaccount.google.com → Security → 2-Step Verification → App passwords → create "Tamagotchi".
       (2-Step Verification must be on. Workspace accounts: your admin must allow app passwords/IMAP.)
   - Your Google Calendar SECRET iCal link:
       calendar.google.com → ⚙ Settings → click your calendar → Integrate calendar →
       "Secret address in iCal format" → copy.
3. Click "Test connection", then "Save".
4. In Gmail settings → "Forwarding and POP/IMAP", make sure IMAP is enabled.

Using it
- Hover a box: see sender + subject. Click a box: opens that email.
- Hover a guest: see the meeting. Click the pet: it hops.
- Drag it anywhere. Right-click: check now, demo mode, snap back to corner, settings, quit.
- Turn on "Demo mode" in the right-click menu to watch a whole day fast-forwarded.

Mail is checked every minute; the calendar every 5 minutes.
Your settings live in %APPDATA%\tamagotchi-desk\config.json (password encrypted with Windows).
