// Tamagotchi Desk — main process
// A tiny always-on-top pet in the bottom-right corner.
//  • Every unread Gmail message received today = a box delivered to its house.
//  • When you read the email, the box goes inside the house.
//  • Every meeting on today's Google Calendar = a guest who visits until it ends.
//  • The pet's activity follows the time of day.

const { app, BrowserWindow, ipcMain, Menu, Tray, screen, shell, safeStorage, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const { fetchTodaysUnread } = require('./src/gmail');
const { fetchTodaysMeetings } = require('./src/calendar');
const demo = require('./src/demo');

const W = 240, H = 200, MARGIN = 12;
const MAIL_POLL_MS = 60 * 1000;
const CAL_POLL_MS = 5 * 60 * 1000;

let win = null, settingsWin = null, tray = null;
let state = { emails: [], meetings: [], mailStatus: 'setup', calStatus: 'setup', mailError: '', calError: '', demo: false, simHour: null, guestLeadMin: 15 };
let mailTimer = null, calTimer = null;

// ---------- config ----------
const configPath = () => path.join(app.getPath('userData'), 'config.json');
function loadConfig() {
  try {
    const c = JSON.parse(fs.readFileSync(configPath(), 'utf8'));
    if (c.passEnc && safeStorage.isEncryptionAvailable()) {
      try { c.pass = safeStorage.decryptString(Buffer.from(c.passEnc, 'base64')); } catch { c.pass = ''; }
    }
    return { guestLeadMin: 15, ...c };
  } catch { return { email: '', pass: '', icalUrl: '', guestLeadMin: 15, startAtLogin: false }; }
}
function saveConfig(c) {
  const out = { email: c.email || '', icalUrl: c.icalUrl || '', guestLeadMin: Number(c.guestLeadMin) || 0, startAtLogin: !!c.startAtLogin, pos: c.pos };
  if (c.pass) {
    if (safeStorage.isEncryptionAvailable()) out.passEnc = safeStorage.encryptString(c.pass).toString('base64');
    else out.passPlain = c.pass;
  }
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify(out, null, 2));
}
let config = null;
const getPass = () => config.pass || config.passPlain || '';

// ---------- window ----------
function cornerPos() {
  const wa = screen.getPrimaryDisplay().workArea;
  return { x: wa.x + wa.width - W - MARGIN, y: wa.y + wa.height - H - MARGIN };
}
function createWindow() {
  const p = config.pos || cornerPos();
  win = new BrowserWindow({
    width: W, height: H, x: p.x, y: p.y,
    frame: false, transparent: true, resizable: false, maximizable: false, fullscreenable: false,
    alwaysOnTop: true, skipTaskbar: true, hasShadow: false, show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false }
  });
  win.setAlwaysOnTop(true, 'floating');
  win.setVisibleOnAllWorkspaces(true);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => { win.showInactive(); push(); });
  win.webContents.on('did-finish-load', push);
  // keep it in the corner if the screen layout changes
  screen.on('display-metrics-changed', () => { if (!config.pos && win) { const c = cornerPos(); win.setPosition(c.x, c.y); } });
}
function push() { if (win && !win.isDestroyed()) win.webContents.send('state', state); }

function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) { settingsWin.focus(); return; }
  settingsWin = new BrowserWindow({
    width: 440, height: 560, resizable: false, minimizable: false, maximizable: false, title: 'Tamagotchi settings',
    autoHideMenuBar: true, webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true }
  });
  settingsWin.loadFile(path.join(__dirname, 'renderer', 'settings.html'));
}

function contextMenu() {
  return Menu.buildFromTemplate([
    { label: 'Do a trick!', click: () => win.webContents.send('trick') },
    { label: 'Check mail now', click: () => { pollMail(); pollCal(); } },
    { label: 'Open Gmail', click: () => shell.openExternal('https://mail.google.com/mail/u/0/#inbox') },
    { label: 'Open Calendar', click: () => shell.openExternal('https://calendar.google.com/calendar/u/0/r/day') },
    { type: 'separator' },
    { label: 'Demo mode (preview everything)', type: 'checkbox', checked: state.demo, click: (m) => toggleDemo(m.checked) },
    { label: 'Snap back to corner', click: () => { config.pos = undefined; saveConfig(config); const c = cornerPos(); win.setPosition(c.x, c.y); } },
    { label: 'Settings…', click: openSettings },
    { label: 'Reload', click: () => win.reload() },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]);
}

// ---------- data polling ----------
async function pollMail() {
  if (state.demo) return;
  if (!config.email || !getPass()) { state.mailStatus = 'setup'; push(); return; }
  try {
    state.emails = await fetchTodaysUnread(config.email, getPass());
    state.mailStatus = 'ok'; state.mailError = '';
  } catch (e) {
    state.mailStatus = 'error'; state.mailError = String(e && (e.responseText || e.message) || e);
    console.error('[mail]', state.mailError);
  }
  push();
}
async function pollCal() {
  if (state.demo) return;
  if (!config.icalUrl) { state.calStatus = 'setup'; state.meetings = []; push(); return; }
  try {
    state.meetings = await fetchTodaysMeetings(config.icalUrl, config.email);
    state.calStatus = 'ok'; state.calError = '';
  } catch (e) {
    state.calStatus = 'error'; state.calError = String(e && e.message || e);
    console.error('[cal]', state.calError);
  }
  push();
}
function startPolling() {
  clearInterval(mailTimer); clearInterval(calTimer);
  state.guestLeadMin = config.guestLeadMin;
  pollMail(); pollCal();
  mailTimer = setInterval(pollMail, MAIL_POLL_MS);
  calTimer = setInterval(pollCal, CAL_POLL_MS);
}
function toggleDemo(on) {
  state.demo = on;
  if (on) {
    demo.start((d) => { Object.assign(state, d); push(); });
  } else {
    demo.stop(); state.simHour = null; state.emails = []; state.meetings = [];
    startPolling();
  }
  push();
}

// ---------- IPC ----------
ipcMain.on('menu', () => contextMenu().popup({ window: win }));
ipcMain.on('open-url', (_e, url) => { if (/^https:\/\/(mail|calendar)\.google\.com\//.test(url)) shell.openExternal(url); });
ipcMain.on('open-settings', openSettings);
let dragStart = null;
ipcMain.on('drag-start', () => { dragStart = { win: win.getPosition(), cursor: screen.getCursorScreenPoint() }; });
ipcMain.on('drag-move', () => {
  if (!dragStart) return;
  const c = screen.getCursorScreenPoint();
  win.setPosition(dragStart.win[0] + c.x - dragStart.cursor.x, dragStart.win[1] + c.y - dragStart.cursor.y);
});
ipcMain.on('drag-end', () => {
  if (!dragStart) return; dragStart = null;
  const [x, y] = win.getPosition(); config.pos = { x, y }; saveConfig(config);
});
ipcMain.handle('get-config', () => ({ email: config.email, hasPass: !!getPass(), icalUrl: config.icalUrl, guestLeadMin: config.guestLeadMin, startAtLogin: config.startAtLogin }));
ipcMain.handle('save-config', (_e, c) => {
  config = { ...config, email: (c.email || '').trim(), icalUrl: (c.icalUrl || '').trim(), guestLeadMin: Number(c.guestLeadMin) || 0, startAtLogin: !!c.startAtLogin };
  if (c.pass) config.pass = c.pass.replace(/\s+/g, ''); // Google shows app passwords with spaces
  saveConfig(config);
  app.setLoginItemSettings({ openAtLogin: config.startAtLogin, path: process.execPath, args: app.isPackaged ? [] : [app.getAppPath()] });
  if (!state.demo) startPolling();
  return true;
});
ipcMain.handle('test-config', async (_e, c) => {
  const out = {};
  try { const m = await fetchTodaysUnread(c.email.trim(), (c.pass || getPass()).replace(/\s+/g, '')); out.mail = `✓ Connected — ${m.length} unread today`; }
  catch (e) { out.mail = '✗ ' + (e.responseText || e.message || e); }
  if (c.icalUrl) {
    try { const m = await fetchTodaysMeetings(c.icalUrl.trim(), c.email.trim()); out.cal = `✓ Connected — ${m.length} meeting(s) today`; }
    catch (e) { out.cal = '✗ ' + (e.message || e); }
  } else out.cal = '(no calendar link yet)';
  return out;
});

// ---------- app ----------
app.setAppUserModelId('tamagotchi.desk');
if (!app.requestSingleInstanceLock()) app.quit();
// running start.bat again while I'm open reloads me with the newest files
app.on('second-instance', () => { if (win) { win.reload(); win.showInactive(); } });
app.whenReady().then(() => {
  config = loadConfig();
  createWindow();
  try {
    tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'icon.png')));
    tray.setToolTip('Tamagotchi');
    tray.on('click', () => win && win.showInactive());
    tray.setContextMenu(contextMenu());
    tray.on('right-click', () => tray.popUpContextMenu(contextMenu()));
  } catch (e) { console.error('tray', e); }
  if (!config.email) setTimeout(openSettings, 800);
  startPolling();
});
app.on('window-all-closed', () => { /* stay alive in the corner; quit from the right-click menu */ });
