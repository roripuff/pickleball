const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('pet', {
  onState: (cb) => ipcRenderer.on('state', (_e, s) => cb(s)),
  onTrick: (cb) => ipcRenderer.on('trick', () => cb()),
  menu: () => ipcRenderer.send('menu'),
  openUrl: (u) => ipcRenderer.send('open-url', u),
  openSettings: () => ipcRenderer.send('open-settings'),
  dragStart: () => ipcRenderer.send('drag-start'),
  dragMove: () => ipcRenderer.send('drag-move'),
  dragEnd: () => ipcRenderer.send('drag-end'),
  getConfig: () => ipcRenderer.invoke('get-config'),
  saveConfig: (c) => ipcRenderer.invoke('save-config', c),
  testConfig: (c) => ipcRenderer.invoke('test-config', c)
});
