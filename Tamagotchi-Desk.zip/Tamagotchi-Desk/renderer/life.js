// Life: moods (happy / sweet / sad) and idle antics (wander, fly, peekaboo, close-up peek, butterfly, stargazing).
(() => {
  const IDLE_MS = 60 * 1000;          // do something fun after ~1 minute of nothing happening
  const SIGH_EVERY_MS = 40 * 1000;    // how often a sad baseline shows itself
  const LONELY_AFTER_MS = 2 * 3600e3; // no pets for 2h → lonely

  let nextIdleAt = Date.now() + IDLE_MS;
  let lastPetted = Date.now(), lastSigh = 0, lastAntic = '';
  let mood = null;   // { name, until, label }
  let run = null;    // the running antic
  let clicks = [];

  // ---------- emotes ----------
  const EMOTES = {
    happy: '<span class="e-note">♪</span>',
    sweet: '<span class="e-heart">♥</span>',
    sad: '<svg viewBox="0 0 20 17" class="e-cloud"><path d="M5 9.5 a3.5 3.5 0 0 1 .8 -6.9 a4.6 4.6 0 0 1 8.5 1.2 a3 3 0 0 1 .7 5.7z" fill="#bcc5d8"/><path d="M7 12 l-.8 3 M10.6 12 l-.8 3 M14.2 12 l-.8 3" class="rain"/></svg>',
    wow: '<span class="e-wow">!</span>',
    curious: '<span class="e-wow">?</span>',
    sparkle: '<span class="e-spark">✦</span>'
  };
  const emoteEl = host.querySelector('.emote');
  function emote(kind) {
    emoteEl.innerHTML = kind ? EMOTES[kind] : '';
    emoteEl.className = 'emote' + (kind ? ' show' : '');
  }
  const MOOD_FACE = { happy: 'grin', sweet: 'sweet', sad: 'sad' };

  function setMood(name, ms, label, face) {
    mood = { name, until: Date.now() + ms, label, face };
    emote(name);
    clearTimeout(setMood.t);
    setMood.t = setTimeout(() => { mood = null; emote(run && run.emote); tick(); }, ms);
    tick();
  }
  const moodActive = () => mood && Date.now() < mood.until;
  function touch() { nextIdleAt = Date.now() + IDLE_MS + Math.random() * 20000; }

  const awake = () => activityAt(currentHour())[1] !== 'sleep';
  const playing = () => stage.classList.contains('playing');
  const overwhelmed = () => state.emails.length >= 6;
  const lonely = () => Date.now() - lastPetted > LONELY_AFTER_MS;

  // ---------- little body animations ----------
  const squash = () => host.querySelector('.pet-squash');
  function droop() { squash().animate([{ transform: 'none' }, { transform: 'scale(1.08,.88)' }, { transform: 'scale(1.06,.9)' }, { transform: 'none' }], { duration: 1600, easing: 'ease-in-out' }); }
  function spin() {
    if (run) return;
    host.animate([{ transform: 'none' }, { transform: 'translateY(-14px) rotate(180deg)' }, { transform: 'rotate(360deg)' }], { duration: 650, easing: 'ease-in-out' });
  }
  function celebrate() {
    if (run) { heart(140, 110, '✦'); return; }
    host.animate([
      { transform: 'none' }, { transform: 'translateY(-18px) rotate(-8deg)' }, { transform: 'none' },
      { transform: 'translateY(-14px) rotate(8deg)' }, { transform: 'none' }, { transform: 'translateY(-20px) rotate(360deg)' }, { transform: 'none' }
    ], { duration: 1800, easing: 'ease-in-out' });
    [0, 250, 500, 800].forEach((d, i) => setTimeout(() => heart(116 + i * 9, 118 - (i % 2) * 8, i % 2 ? '✦' : '♥'), d));
  }

  // ---------- events from the scene ----------
  life.event = (type, data) => {
    const now = Date.now();
    switch (type) {
      case 'pet-clicked': {
        touch(); lastPetted = now;
        clicks = clicks.filter((t) => now - t < 2500); clicks.push(now);
        if (clicks.length >= 3) { clicks = []; setMood('happy', 4000, 'giggling!'); spin(); heart(140, 120, '♪'); }
        else {
          const wasSad = moodActive() && mood.name === 'sad';
          setMood('sweet', 4000, wasSad ? 'feeling better' : null);
          boop(host); heart(126, 128); setTimeout(() => heart(142, 124), 200);
        }
        break;
      }
      case 'hover': touch(); break;
      case 'dragged': touch(); life.cancel(); setMood('happy', 2500, 'wheee!'); break;
      case 'box-arrived': touch(); boop(host);
        setMood(overwhelmed() ? 'sad' : 'happy', 3000, overwhelmed() ? 'another box…' : 'a box arrived!'); break;
      case 'box-read':
        touch();
        if (data && data.left === 0) { setMood('happy', 6000, 'all boxes tidy!'); celebrate(); }
        else setMood('sweet', 2500, 'thank you!');
        break;
      case 'guest-arrived': touch(); setMood('sweet', 5000); break;
      case 'guest-left': touch(); life.cancel(); setMood('sad', 15000, 'misses ' + ((data && data.title) || 'friend')); droop(); break;
    }
  };
  life.face = () => (run && run.face) || (moodActive() ? (mood.face || MOOD_FACE[mood.name]) : null);
  life.label = () => (run && run.label) || (moodActive() && mood.label) || null;
  life.moodText = () => {
    const m = moodActive() ? mood.name : overwhelmed() ? 'overwhelmed' : lonely() ? 'lonely' : 'content';
    const icon = { happy: '♪', sweet: '♥', sad: '☁', overwhelmed: '☁', lonely: '☁', content: '☺' }[m];
    return `mood: ${m} ${icon} · `;
  };
  life.busy = () => !!run;
  life.cancel = () => {
    if (!run) return;
    run.cancelled = true;
    run.anims.forEach((a) => { try { a.cancel(); } catch { /* */ } });
    run.rejecters.forEach((f) => f());
  };

  // ---------- antic toolkit ----------
  class Cancelled extends Error {}
  const wait = (r, ms) => new Promise((res, rej) => {
    if (r.cancelled) return rej(new Cancelled());
    const t = setTimeout(res, ms);
    r.rejecters.push(() => { clearTimeout(t); rej(new Cancelled()); });
  });
  function anim(r, el, frames, opts) {
    if (r.cancelled) return Promise.reject(new Cancelled());
    const a = el.animate(frames, { fill: 'forwards', ...opts });
    r.anims.push(a);
    return a.finished;
  }
  const at = (x, y = 0, extra = '') => `translate(${x}px, ${y}px) ${extra}`;
  async function walkTo(r, x, speed = 32) {
    const from = r.x;
    if (x === from) return;
    host.classList.toggle('face-left', x < from);
    host.classList.add('walking');
    await anim(r, host, [{ transform: at(from) }, { transform: at(x) }], { duration: Math.abs(x - from) * speed + 150, easing: 'ease-in-out' });
    host.classList.remove('walking');
    r.x = x;
  }
  const rand = (a, b) => a + Math.random() * (b - a);

  // ---------- the antics ----------
  const ANTICS = {
    async wander(r) {
      r.label = 'wandering';
      let x = Math.round(Math.random() < .5 ? rand(-38, -18) : rand(25, 72));
      await walkTo(r, x);
      r.face = 'happy'; emote('curious'); r.emote = 'curious';
      await wait(r, 700);
      host.classList.toggle('face-left'); await wait(r, 700);
      host.classList.toggle('face-left'); await wait(r, 600);
      emote(null); r.emote = null;
      if (Math.random() < .5) { r.face = 'grin'; r.label = 'humming'; emote('happy'); await wait(r, 1800); emote(null); }
      else { x = Math.round(x > 0 ? rand(-30, -10) : rand(20, 50)); r.label = 'strolling'; await walkTo(r, x); await wait(r, 600); }
      r.face = null; r.label = 'heading back';
      await walkTo(r, 0);
    },

    async fly(r) {
      r.label = 'flying!'; r.face = 'grin';
      host.classList.add('flying');
      await anim(r, host, [{ transform: at(0, 0) }, { transform: at(0, -10, 'rotate(-4deg)') }], { duration: 700, easing: 'ease-out' });
      emote('happy');
      await anim(r, host, [
        { transform: at(0, -10, 'rotate(-4deg)') },
        { transform: at(35, -55, 'rotate(10deg)') },
        { transform: at(70, -95, 'rotate(6deg)') },
        { transform: at(30, -112, 'rotate(-8deg)') },
        { transform: at(-25, -100, 'rotate(-14deg)') },
        { transform: at(-62, -70, 'rotate(-6deg)') },
        { transform: at(-40, -35, 'rotate(8deg)') },
        { transform: at(-10, -14, 'rotate(4deg)') },
        { transform: at(0, -8) }
      ], { duration: 8200, easing: 'ease-in-out' });
      emote(null);
      await anim(r, host, [{ transform: at(0, -8) }, { transform: at(0, 0, 'scale(1.12,.86)') }, { transform: at(0, 0) }], { duration: 500, easing: 'ease-in' });
      host.classList.remove('flying');
      r.face = 'sweet'; r.label = 'that was fun';
      await wait(r, 1200);
    },

    async peekaboo(r) {
      r.label = 'where did he go?';
      await walkTo(r, 140);
      await wait(r, 1400);
      r.label = 'peekaboo!'; r.face = 'happy';
      host.classList.add('face-left');
      await anim(r, host, [{ transform: at(150, 0, 'rotate(-20deg)') }, { transform: at(108, 2, 'rotate(-20deg)') }], { duration: 450, easing: 'ease-out' });
      emote('curious');
      await wait(r, 1800);
      r.face = 'sweet'; emote('sweet');
      await wait(r, 1200);
      emote(null);
      await anim(r, host, [{ transform: at(108, 2, 'rotate(-20deg)') }, { transform: at(150, 0, 'rotate(-20deg)') }], { duration: 300, easing: 'ease-in' });
      await wait(r, 800);
      r.face = 'grin'; r.label = 'boo!';
      r.x = 140; await walkTo(r, 0, 22);
    },

    async closeup(r) {
      r.label = 'hi there!'; r.face = 'happy';
      host.classList.add('closeup');
      emote(null);
      await anim(r, host, [{ transform: 'none' }, { transform: at(-14, 12, 'scale(3.4)') }], { duration: 1100, easing: 'cubic-bezier(.3,.7,.3,1)' });
      await wait(r, 900);
      r.face = 'grin';
      // press against the glass
      const fog = document.getElementById('fog');
      await anim(r, host, [{ transform: at(-14, 12, 'scale(3.4)') }, { transform: at(-14, 14, 'scale(3.65,3.2)') }, { transform: at(-14, 12, 'scale(3.4)') }], { duration: 500 });
      fog.classList.add('show');
      r.face = 'sweet'; emote('sweet');
      await wait(r, 2200);
      emote(null); r.face = 'happy';
      await wait(r, 700);
      fog.classList.remove('show');
      await anim(r, host, [{ transform: at(-14, 12, 'scale(3.4)') }, { transform: 'none' }], { duration: 900, easing: 'ease-in-out' });
      host.classList.remove('closeup');
    },

    async butterfly(r) {
      r.label = 'ooh, a butterfly';
      const b = document.createElement('div');
      b.className = 'butterfly';
      b.innerHTML = '<svg viewBox="0 0 14 12"><g class="wing wl"><path d="M7 6 C2 0 0 3 1 6 C0 9 3 11 7 7Z" fill="#ffb3d1"/></g><g class="wing wr"><path d="M7 6 C12 0 14 3 13 6 C14 9 11 11 7 7Z" fill="#ffc98a"/></g><ellipse cx="7" cy="6.5" rx=".8" ry="2.6" fill="#7a5a6a"/></svg>';
      stage.appendChild(b);
      r.cleanup.push(() => b.remove());
      const fly = anim(r, b, [
        { left: '250px', top: '70px' }, { left: '200px', top: '100px' }, { left: '178px', top: '118px' },
        { left: '190px', top: '128px' }, { left: '170px', top: '112px' }, { left: '182px', top: '122px' },
        { left: '150px', top: '60px' }, { left: '90px', top: '30px' }, { left: '-20px', top: '10px' }
      ], { duration: 9000, easing: 'ease-in-out' });
      emote('wow'); r.face = 'happy';
      await wait(r, 1600);
      emote(null); r.face = 'grin'; r.label = 'chasing a butterfly';
      await walkTo(r, 45, 28);
      for (let i = 0; i < 2; i++) {
        await anim(r, host, [{ transform: at(45) }, { transform: at(45, -20, 'scale(.95,1.06)') }, { transform: at(45, 0, 'scale(1.1,.9)') }, { transform: at(45) }], { duration: 650, easing: 'ease-out' });
        await wait(r, 450);
      }
      host.classList.add('face-left');
      r.face = 'sweet'; r.label = 'bye butterfly'; emote('sweet');
      await fly.catch(() => {});
      emote(null);
      await walkTo(r, 0);
    },

    async stargaze(r) {
      r.label = 'stargazing'; r.face = 'happy';
      await walkTo(r, 30);
      await wait(r, 1000);
      const s = document.createElement('div');
      s.className = 'shoot'; stage.appendChild(s);
      r.cleanup.push(() => s.remove());
      anim(r, s, [{ left: '230px', top: '14px', opacity: 0 }, { opacity: 1, offset: .2 }, { left: '70px', top: '64px', opacity: 0 }], { duration: 1100, easing: 'ease-in' }).catch(() => {});
      await wait(r, 500);
      emote('wow'); r.face = 'grin'; r.label = 'a shooting star!';
      await wait(r, 1600);
      emote('sparkle'); r.face = 'sweet'; r.label = 'making a wish';
      await wait(r, 2400);
      emote(null);
      await walkTo(r, 0);
    }
  };

  async function startAntic(name) {
    const r = { name, x: 0, anims: [], rejecters: [], cleanup: [], cancelled: false, face: null, label: null, emote: null };
    run = r;
    stage.classList.add('antic');
    host.classList.add('free');
    try { await ANTICS[name](r); }
    catch (e) { if (!(e instanceof Cancelled) && e.name !== 'AbortError') console.error(e); }
    finally {
      r.cancelled = true;
      r.anims.forEach((a) => { try { a.cancel(); } catch { /* */ } });
      r.cleanup.forEach((f) => f());
      host.classList.remove('free', 'walking', 'flying', 'face-left', 'closeup');
      document.getElementById('fog').classList.remove('show');
      stage.classList.remove('antic');
      if (!moodActive()) emote(null);
      run = null; lastAntic = name; touch(); tick();
    }
  }

  function pickAntic() {
    const day = skyAt(currentHour()).dark < .4;
    const pool = day ? ['wander', 'wander', 'fly', 'fly', 'peekaboo', 'closeup', 'butterfly', 'butterfly']
                     : ['wander', 'fly', 'peekaboo', 'closeup', 'stargaze', 'stargaze'];
    const options = pool.filter((n) => n !== lastAntic);
    return options[Math.floor(Math.random() * options.length)];
  }

  // ---------- heartbeat ----------
  setInterval(() => {
    const now = Date.now();
    if (run || playing() || (down && dragging)) return;
    if (!awake()) {
      // while asleep: an occasional dream instead of antics
      if (now >= nextIdleAt) { touch(); setMood('sweet', 5000, 'dreaming…', 'sleep'); }
      return;
    }
    if (now >= nextIdleAt && !moodActive()) { startAntic(pickAntic()); return; }
    if (!moodActive() && (overwhelmed() || lonely()) && now - lastSigh > SIGH_EVERY_MS) {
      lastSigh = now;
      setMood('sad', 6000, overwhelmed() ? 'so many boxes…' : 'feeling lonely');
      droop();
    }
  }, 1000);

  // right-click → "Do a trick!"
  if (api.onTrick) api.onTrick(() => { if (!playing()) window.__antic(); });

  // handy for previewing: window.__antic('fly')
  window.__antic = (n) => { life.cancel(); setTimeout(() => startAntic(n || pickAntic()), 50); };
  window.__pet = () => life.event('pet-clicked');
  window.__stop = () => life.cancel();
  window.__mood = (m, label, ms) => { if (!m) { mood = null; emote(null); tick(); return; } setMood(m, ms || 6000, label); };
})();
