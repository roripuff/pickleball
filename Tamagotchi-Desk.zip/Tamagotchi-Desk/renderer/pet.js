// Soft vector pet sprite. Faces and arms are toggled with data attributes in CSS.
const PALETTES = {
  host:     { body: '#ffc9a8', shade: '#f4a98a', belly: '#fff0e4', leaf: '#7fcf8c' },
  mint:     { body: '#bfeedd', shade: '#8fd6bd', belly: '#effcf6', leaf: '#ff9fb6' },
  lavender: { body: '#dccbff', shade: '#b9a2f2', belly: '#f6f0ff', leaf: '#ffd36e' },
  lemon:    { body: '#fff0a6', shade: '#f1d76a', belly: '#fffbe6', leaf: '#8fd0ff' },
  sky:      { body: '#c4e4ff', shade: '#93c6f2', belly: '#f0f8ff', leaf: '#ff9fa8' }
};
const GUEST_COLORS = ['mint', 'lavender', 'lemon', 'sky'];

function guestPalette(id) {
  let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return GUEST_COLORS[h % GUEST_COLORS.length];
}

function makePet(paletteName, extraClass = '') {
  const p = PALETTES[paletteName];
  const uid = Math.random().toString(36).slice(2, 8);
  const el = document.createElement('div');
  el.className = 'pet ' + extraClass;
  el.dataset.face = 'happy';
  el.innerHTML = `
  <div class="pet-hop"><div class="pet-squash">
  <svg viewBox="0 0 40 40" class="pet-svg">
    <defs>
      <radialGradient id="g${uid}" cx="38%" cy="30%" r="75%">
        <stop offset="0" stop-color="#ffffff" stop-opacity=".55"/>
        <stop offset=".45" stop-color="${p.body}" stop-opacity="1"/>
        <stop offset="1" stop-color="${p.shade}"/>
      </radialGradient>
    </defs>
    <ellipse class="shadow" cx="20" cy="38.3" rx="12" ry="1.8"/>
    <ellipse cx="13.5" cy="36.2" rx="4.3" ry="2.4" fill="${p.shade}"/>
    <ellipse cx="26.5" cy="36.2" rx="4.3" ry="2.4" fill="${p.shade}"/>
    <g class="arm arm-l"><ellipse cx="5.2" cy="25" rx="2.8" ry="4" fill="${p.shade}"/></g>
    <g class="arm arm-r"><ellipse cx="34.8" cy="25" rx="2.8" ry="4" fill="${p.shade}"/></g>
    <g class="sprout"><path d="M20 6 Q19.4 3 20.5 0.8" stroke="${p.leaf}" stroke-width="1.4" fill="none" stroke-linecap="round"/>
      <path d="M20.4 1.6 q4.6 -2.4 6.6 0.6 q-3.6 2.6 -6.6 -0.6z" fill="${p.leaf}"/></g>
    <path d="M20 5.2 C31 5.2 36.4 14.5 36.4 24.2 C36.4 32.4 29.4 37.2 20 37.2 C10.6 37.2 3.6 32.4 3.6 24.2 C3.6 14.5 9 5.2 20 5.2Z" fill="url(#g${uid})"/>
    <ellipse cx="20" cy="29.5" rx="9.5" ry="6" fill="${p.belly}" opacity=".85"/>
    <g class="face">
      <g class="eyes-open"><ellipse cx="14.2" cy="19.6" rx="2.5" ry="3.1" class="eye"/><ellipse cx="25.8" cy="19.6" rx="2.5" ry="3.1" class="eye"/>
        <circle cx="15" cy="18.4" r=".95" fill="#fff"/><circle cx="26.6" cy="18.4" r=".95" fill="#fff"/></g>
      <g class="eyes-closed"><path d="M11.8 20 q2.4 2.2 4.8 0 M23.4 20 q2.4 2.2 4.8 0" class="lid"/></g>
      <g class="eyes-happy"><path d="M11.8 21 q2.4 -3 4.8 0 M23.4 21 q2.4 -3 4.8 0" class="lid"/></g>
      <g class="eyes-focus"><ellipse cx="15" cy="20.6" rx="2" ry="2.3" class="eye"/><ellipse cx="26.6" cy="20.6" rx="2" ry="2.3" class="eye"/><circle cx="15.7" cy="19.8" r=".7" fill="#fff"/><circle cx="27.3" cy="19.8" r=".7" fill="#fff"/></g>
      <ellipse cx="10.2" cy="24.6" rx="2.8" ry="1.6" class="cheek"/><ellipse cx="29.8" cy="24.6" rx="2.8" ry="1.6" class="cheek"/>
      <g class="brows-sad"><path d="M11.6 15.6 L16.2 14.2 M23.8 14.2 L28.4 15.6" class="lid"/></g>
      <path class="mouth-smile" d="M17.6 24.2 Q20 26.8 22.4 24.2"/>
      <path class="mouth-frown" d="M17.8 26.2 Q20 24 22.2 26.2"/>
      <path class="mouth-grin" d="M16.8 23.4 Q20 29.4 23.2 23.4Z"/>
      <path class="mouth-kiss" d="M19.4 23.6 q1.6 .8 0 1.6 q1.6 .8 0 1.6"/>
      <ellipse class="tear" cx="12.6" cy="23.4" rx="1" ry="1.4"/>
      <ellipse class="mouth-o" cx="20" cy="25.4" rx="1.7" ry="2"/>
      <path class="mouth-chew" d="M17.8 25 q1.1 -1 2.2 0 q1.1 1 2.2 0"/>
    </g>
  </svg></div></div><div class="emote"></div>`;
  return el;
}
