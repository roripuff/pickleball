// Scene controller: sky, activities, boxes (emails) and guests (meetings).
const $ = (s) => document.querySelector(s);
const stage = $('#stage');
const api = window.pet || browserPreviewApi();

let state = { emails: [], meetings: [], mailStatus: 'setup', calStatus: 'setup', simHour: null, guestLeadMin: 15 };
let firstSync = true;

// ---------- host pet ----------
const host = makePet('host', 'host');
$('#pets').appendChild(host);
let tempFace = null, tempFaceUntil = 0;
// life.js fills these in (moods + idle antics)
const life = { event() {}, face() { return null; }, label() { return null; }, moodText() { return ''; }, busy() { return false; }, cancel() {} };
function flashFace(face, ms) { tempFace = face; tempFaceUntil = Date.now() + ms; tick(); }
function boop(el) { el.classList.remove('boop'); void el.offsetWidth; el.classList.add('boop'); setTimeout(() => el.classList.remove('boop'), 650); }
function heart(x, y, ch = '♥') {
  const h = document.createElement('span'); h.className = 'heart'; h.textContent = ch;
  h.style.left = x + 'px'; h.style.top = y + 'px'; $('#hearts').appendChild(h); setTimeout(() => h.remove(), 1700);
}

// ---------- time of day ----------
const SKY = [ // hour, sky top, sky bottom, ground front, ground back, darkness, window light
  [0, '#1c2150', '#3a3f7c', '#4f7a6e', '#3e6660', 1, '#ffe39a'],
  [5, '#232a5e', '#4a4c8a', '#557f70', '#436b62', .9, '#ffe39a'],
  [6.2, '#ffb3a7', '#ffe2b8', '#a9d99a', '#86c886', .25, '#ffe8b0'],
  [7.6, '#9fd8ff', '#e3f5ff', '#bfe8a8', '#93d48e', 0, '#cfeeff'],
  [16.6, '#a6d9ff', '#eaf6ff', '#bfe8a8', '#93d48e', 0, '#cfeeff'],
  [18, '#ff9fa0', '#ffd5a0', '#b4d99a', '#8fc78a', .15, '#ffe39a'],
  [19.4, '#6a5a9e', '#d79bb8', '#7fa58a', '#6a9180', .6, '#ffe39a'],
  [20.6, '#1c2150', '#3a3f7c', '#4f7a6e', '#3e6660', 1, '#ffe39a'],
  [24, '#1c2150', '#3a3f7c', '#4f7a6e', '#3e6660', 1, '#ffe39a']
];
const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mix = (a, b, t) => '#' + hex(a).map((v, i) => Math.round(v + (hex(b)[i] - v) * t).toString(16).padStart(2, '0')).join('');
function skyAt(h) {
  let i = 0; while (i < SKY.length - 2 && SKY[i + 1][0] <= h) i++;
  const a = SKY[i], b = SKY[i + 1], t = Math.min(1, Math.max(0, (h - a[0]) / (b[0] - a[0])));
  return { s1: mix(a[1], b[1], t), s2: mix(a[2], b[2], t), g1: mix(a[3], b[3], t), g2: mix(a[4], b[4], t), dark: a[5] + (b[5] - a[5]) * t, win: mix(a[6], b[6], t) };
}

const ACTIVITIES = [ // from hour, key, label, face, extra classes
  [0, 'sleep', 'sleeping', 'sleep'],
  [6, 'wake', 'waking up', 'yawn', 'morning'],
  [7.5, 'eat', 'breakfast', 'chew', 'act-breakfast cooking'],
  [9, 'work', 'working', 'focus', 'morning'],
  [12, 'eat', 'lunch', 'chew', 'cooking'],
  [13, 'garden', 'watering plants', 'joy'],
  [14, 'work', 'working', 'focus'],
  [17.5, 'play', 'playing outside', 'joy'],
  [19, 'eat', 'dinner', 'chew', 'cooking dim'],
  [20, 'read', 'reading', 'happy', 'dim'],
  [22, 'sleep', 'sleeping', 'sleep', 'dim']
];
function activityAt(h) { let a = ACTIVITIES[0]; for (const x of ACTIVITIES) if (h >= x[0]) a = x; return a; }

function currentHour() {
  if (state.simHour != null) return state.simHour;
  const d = new Date(); return d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600;
}
const fmt = (d) => d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
function fmtHour(h) { const d = new Date(); d.setHours(Math.floor(h), Math.floor((h % 1) * 60), 0, 0); return fmt(d); }

// ---------- boxes (emails) ----------
const boxes = new Map(); // id -> {el, email}
const SLOT = (i) => ({ left: 68 + (i % 3) * 14, bottom: 34 + Math.floor(i / 3) * 12 });
const MAX_VISIBLE = 9;
function boxSVG() {
  return `<svg viewBox="0 0 13 12"><g class="chute"><path d="M-2 -9 Q6.5 -20 15 -9 Q11 -11 6.5 -9 Q2 -11 -2 -9Z" fill="#ffb3c6"/>
  <path d="M-2 -9 L2.5 1.5 M15 -9 L10.5 1.5 M6.5 -9 V1.5" stroke="#d9a0b4" stroke-width=".5"/></g>
  <rect x=".6" y="1" width="11.8" height="10.6" rx="1.7" fill="#eabb8c" stroke="#c98f5f" stroke-width=".8"/>
  <rect x="5.3" y="1" width="2.4" height="10.6" fill="#fff4dc" opacity=".85"/>
  <path d="M10 3.6 l.9 -.9 a.55 .55 0 0 1 .9 .7 l-.9 1.1 l-.9 -1.1 a.55 .55 0 0 1 0 .2z" fill="#ff8fab"/></svg>`;
}
function syncBoxes(emails) {
  const ids = new Set(emails.map((e) => e.id));
  for (const [id, b] of boxes) if (!ids.has(id)) { boxes.delete(id); sendInside(b.el); }
  let delay = 0;
  emails.forEach((e) => {
    if (boxes.has(e.id)) { boxes.get(e.id).email = e; return; }
    const el = document.createElement('div');
    el.className = 'box'; el.innerHTML = boxSVG(); el.dataset.id = e.id;
    el.addEventListener('mouseenter', () => showTip(`<b>${esc(e.from)}</b><span>${esc(e.subject)} · ${fmt(new Date(e.date))}</span>`));
    el.addEventListener('mouseleave', hideTip);
    el.addEventListener('click', () => api.openUrl(boxes.get(e.id)?.email.url || e.url));
    boxes.set(e.id, { el, email: e });
    stage.appendChild(el);
    const d = delay, initial = firstSync; delay += firstSync ? 220 : 600;
    el.style.visibility = 'hidden';
    setTimeout(() => {
      el.style.visibility = ''; el.classList.add('drop');
      setTimeout(() => { el.classList.remove('drop'); if (!initial) life.event('box-arrived'); }, 1500);
    }, d);
  });
  layoutBoxes(emails);
  firstSync = false;
}
function layoutBoxes(emails) {
  emails.forEach((e, i) => {
    const b = boxes.get(e.id); if (!b) return;
    const s = SLOT(Math.min(i, MAX_VISIBLE - 1));
    b.el.style.left = s.left + 'px'; b.el.style.bottom = s.bottom + 'px';
    b.el.style.display = i < MAX_VISIBLE ? '' : 'none';
    b.el.style.zIndex = 3 + Math.floor(i / 3);
  });
  const extra = emails.length - MAX_VISIBLE, more = $('#more-boxes');
  more.style.display = extra > 0 ? 'block' : 'none'; more.textContent = '+' + extra;
}
let inQueue = [], inBusy = false;
function sendInside(el) { inQueue.push(el); pumpInside(); }
function pumpInside() {
  if (inBusy || !inQueue.length) return;
  inBusy = true;
  const el = inQueue.shift();
  el.classList.remove('drop'); el.style.display = ''; el.style.visibility = '';
  stage.classList.add('door-open');
  setTimeout(() => {
    el.classList.add('going-in');
    el.style.left = '46px'; el.style.bottom = '35px'; el.style.transform = 'scale(.5)'; el.style.opacity = '0';
  }, 280);
  setTimeout(() => {
    el.remove(); heart(54, 129, '✓'); life.event('box-read', { left: state.emails.length });
    if (!inQueue.length) setTimeout(() => stage.classList.remove('door-open'), 150);
    inBusy = false; pumpInside();
  }, 950);
}

// ---------- guests (meetings) ----------
const guests = new Map(); // meeting id -> {el, m}
function activeMeetings(now) {
  const lead = (Number(state.guestLeadMin) || 0) * 60000;
  return state.meetings.filter((m) => now >= new Date(m.start) - lead && now < new Date(m.end));
}
function syncGuests() {
  const now = Date.now();
  const act = activeMeetings(now).slice(0, 2);
  const ids = new Set(act.map((m) => m.id));
  for (const [id, g] of guests) {
    if (ids.has(id)) continue;
    guests.delete(id);
    life.event('guest-left', g.m);
    g.el.classList.add('leaving', 'walking');
    heart(parseInt(getComputedStyle(g.el).left) + 14, 139, '👋');
    setTimeout(() => g.el.classList.add('offstage'), 600);
    setTimeout(() => g.el.remove(), 2600);
  }
  act.forEach((m) => {
    if (guests.has(m.id)) { guests.get(m.id).m = m; return; }
    life.cancel();
    const el = makePet(guestPalette(m.id), 'guest offstage walking');
    el.addEventListener('mouseenter', () => { const g = guests.get(m.id); if (g) showTip(`<b>${esc(g.m.title)}</b><span>${fmt(new Date(g.m.start))} – ${fmt(new Date(g.m.end))}</span>`); });
    el.addEventListener('mouseleave', hideTip);
    el.addEventListener('click', () => { boop(el); heart(parseInt(getComputedStyle(el).left) + 14, 131); });
    $('#pets').appendChild(el);
    guests.set(m.id, { el, m });
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove('offstage')));
    setTimeout(() => { el.classList.remove('walking'); heart(150, 129); heart(176, 123); life.event('guest-arrived', m); }, 1850);
  });
  [...guests.values()].forEach((g, i) => { g.el.classList.toggle('slot0', i === 0); g.el.classList.toggle('slot1', i === 1); });
  const playing = [...guests.values()].some((g) => !g.el.classList.contains('walking') && !g.el.classList.contains('leaving'));
  stage.classList.toggle('playing', playing);
  return act;
}

// ---------- main tick ----------
const ACT_CLASSES = ['act-sleep', 'act-wake', 'act-eat', 'act-work', 'act-garden', 'act-play', 'act-read', 'act-breakfast', 'morning', 'dim', 'cooking'];
let heartTimer = 0;
function tick() {
  const h = currentHour();
  const sky = skyAt(h), r = document.documentElement.style;
  r.setProperty('--sky1', sky.s1); r.setProperty('--sky2', sky.s2); r.setProperty('--g1', sky.g1); r.setProperty('--g2', sky.g2);
  r.setProperty('--dark', sky.dark.toFixed(2)); r.setProperty('--win', sky.win);

  // sun & moon arcs
  const sun = $('#sun'), moon = $('#moon');
  const ts = (h - 6) / 12.5;
  if (ts >= 0 && ts <= 1) { sun.style.opacity = 1; sun.style.left = (16 + 208 * ts) + 'px'; sun.style.top = (128 - 92 * Math.sin(Math.PI * ts)) + 'px'; }
  else sun.style.opacity = 0;
  const tm = (((h - 18.5) + 24) % 24) / 11.5;
  if (tm >= 0 && tm <= 1) { moon.style.opacity = 1; moon.style.left = (16 + 208 * tm) + 'px'; moon.style.top = (128 - 92 * Math.sin(Math.PI * tm)) + 'px'; }
  else moon.style.opacity = 0;

  const act = activityAt(h);
  const meetingsNow = syncGuests();
  const playing = stage.classList.contains('playing');
  ACT_CLASSES.forEach((c) => stage.classList.remove(c));
  if (!playing) {
    stage.classList.add('act-' + act[1]);
    if (act[4]) act[4].split(' ').forEach((c) => stage.classList.add(c));
  } else if (sky.dark > .5) stage.classList.add('dim');

  let face = playing ? 'joy' : act[3];
  const lf = life.face(act[1], playing); if (lf) face = lf;
  if (tempFace && Date.now() < tempFaceUntil) face = tempFace;
  host.dataset.face = face;
  for (const g of guests.values()) g.el.dataset.face = playing ? (Math.floor(Date.now() / 1400) % 3 ? 'happy' : 'joy') : 'happy';

  if (playing && Date.now() - heartTimer > 3500) { heartTimer = Date.now(); heart(158 + Math.random() * 10, 123); }

  $('#clock').textContent = state.simHour != null ? fmtHour(h) : fmt(new Date());
  $('#activity').textContent = life.label() || (playing ? 'playing w/ ' + (meetingsNow[0]?.title || 'a friend') : act[2]);

  const n = state.emails.length;
  $('#mailcount').textContent = n ? '✉ ' + n : '';
  const now = Date.now();
  const ongoing = state.meetings.find((m) => now >= new Date(m.start) && now < new Date(m.end));
  const next = state.meetings.find((m) => new Date(m.start) > now);
  $('#nextmtg').textContent = ongoing ? '● now' : next ? '◷ ' + fmt(new Date(next.start)) : '';
  $('#nextmtg').dataset.tip = ongoing ? `${ongoing.title} · until ${fmt(new Date(ongoing.end))}` : next ? `${next.title} · ${fmt(new Date(next.start))}` : '';

  const sign = $('#sign');
  if (state.mailStatus === 'setup') { sign.className = 'show'; sign.firstChild.textContent = 'set me up!'; sign.title = 'Connect Gmail & Calendar'; }
  else if (state.mailStatus === 'error' || state.calStatus === 'error') {
    sign.className = 'show err'; sign.firstChild.textContent = '!';
    sign.title = [state.mailError && 'Mail: ' + state.mailError, state.calError && 'Calendar: ' + state.calError].filter(Boolean).join('\n');
  } else sign.className = '';
}

// ---------- interactions ----------
function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function showTip(html) { const t = $('#tip'); t.innerHTML = html; t.classList.add('show'); }
function hideTip() { $('#tip').classList.remove('show'); }

host.addEventListener('click', () => life.event('pet-clicked'));
host.addEventListener('mouseenter', () => { life.event('hover'); showTip(`<b>${esc($('#activity').textContent)}</b><span>${life.moodText()}${state.emails.length} box(es) waiting · ${state.meetings.length} meeting(s) today</span>`); });
host.addEventListener('mouseleave', hideTip);
$('#mailcount').addEventListener('click', () => api.openUrl('https://mail.google.com/mail/u/0/#inbox'));
$('#nextmtg').addEventListener('click', () => api.openUrl('https://calendar.google.com/calendar/u/0/r/day'));
$('#nextmtg').addEventListener('mouseenter', (e) => e.target.dataset.tip && showTip(`<b>${esc(e.target.dataset.tip)}</b>`));
$('#nextmtg').addEventListener('mouseleave', hideTip);
$('#sign').addEventListener('click', () => api.openSettings());
$('#sign').addEventListener('mouseenter', (e) => e.currentTarget.title && showTip(`<span style="white-space:normal">${esc(e.currentTarget.title)}</span>`));
$('#sign').addEventListener('mouseleave', hideTip);
stage.addEventListener('contextmenu', (e) => { e.preventDefault(); api.menu(); });

// drag the whole widget anywhere; a short press is still a click
let down = null, dragging = false, suppressClick = false;
stage.addEventListener('mousedown', (e) => { if (e.button === 0) { down = { x: e.screenX, y: e.screenY }; dragging = false; } });
window.addEventListener('mousemove', (e) => {
  if (!down) return;
  if (!dragging && Math.hypot(e.screenX - down.x, e.screenY - down.y) > 4) { dragging = true; api.dragStart(); hideTip(); life.event('dragged'); }
  if (dragging) api.dragMove();
});
// never get stuck thinking the mouse is held down (that would freeze the idle tricks)
window.addEventListener('blur', () => { if (dragging) api.dragEnd(); down = null; dragging = false; });
stage.addEventListener('mouseleave', (e) => { if (!e.buttons && !dragging) down = null; });
window.addEventListener('mouseup', () => { if (dragging) { api.dragEnd(); suppressClick = true; setTimeout(() => (suppressClick = false), 50); } down = null; dragging = false; });
stage.addEventListener('click', (e) => { if (suppressClick) { e.stopPropagation(); e.preventDefault(); } }, true);

// ---------- wire up ----------
api.onState((s) => { state = { ...state, ...s }; syncBoxes(state.emails); tick(); });
setInterval(tick, 1000);
tick();

// When opened in a normal browser (for previewing), fake the bridge. ?hour=10&mail=3&guest=1
function browserPreviewApi() {
  const q = new URLSearchParams(location.search);
  return {
    onState(cb) {
      const now = Date.now();
      const mail = Number(q.get('mail') || 0);
      setTimeout(() => cb({
        simHour: q.has('hour') ? Number(q.get('hour')) : null, mailStatus: q.get('status') || 'ok', calStatus: 'ok',
        emails: Array.from({ length: mail }, (_, i) => ({ id: 'p' + i, from: 'Sender ' + i, subject: 'Hello ' + i, date: new Date().toISOString(), url: '#' })),
        meetings: Array.from({ length: Number(q.get('guest') || 0) }, (_, i) => ({ id: 'g' + i, title: 'Design sync', start: new Date(now - 6e4).toISOString(), end: new Date(now + 36e5).toISOString() }))
      }), 10);
      window.__push = cb;
    },
    onTrick() {}, menu() {}, openUrl() {}, openSettings() {}, dragStart() {}, dragMove() {}, dragEnd() {}
  };
}
