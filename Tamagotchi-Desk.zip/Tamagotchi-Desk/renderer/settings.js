const $ = (id) => document.getElementById(id);
const read = () => ({ email: $('email').value, pass: $('pass').value, icalUrl: $('ical').value, guestLeadMin: $('lead').value, startAtLogin: $('login').checked });

window.pet.getConfig().then((c) => {
  $('email').value = c.email || '';
  $('ical').value = c.icalUrl || '';
  $('lead').value = c.guestLeadMin ?? 15;
  $('login').checked = !!c.startAtLogin;
  if (c.hasPass) $('pass').placeholder = '•••••••• (saved — leave blank to keep)';
});

$('test').onclick = async () => {
  $('result').textContent = 'Knocking on the mailbox…';
  const r = await window.pet.testConfig(read());
  $('result').textContent = `Mail: ${r.mail}\nCalendar: ${r.cal}`;
};
$('save').onclick = async () => {
  await window.pet.saveConfig(read());
  $('result').textContent = 'Saved! Boxes should start arriving within a minute.';
  setTimeout(() => window.close(), 900);
};
