// Reads today's meetings from a Google Calendar "Secret address in iCal format".
// Google Calendar → Settings → (your calendar) → Integrate calendar → Secret address in iCal format.
const ical = require('node-ical');

function dayBounds() {
  const s = new Date(); s.setHours(0, 0, 0, 0);
  const e = new Date(s); e.setDate(e.getDate() + 1);
  return [s, e];
}

function declined(ev, myEmail) {
  if (!myEmail || !ev.attendee) return false;
  const list = Array.isArray(ev.attendee) ? ev.attendee : [ev.attendee];
  const me = myEmail.toLowerCase();
  return list.some((a) => {
    const val = String(typeof a === 'string' ? a : a.val || '').toLowerCase();
    const ps = typeof a === 'object' && a.params ? String(a.params.PARTSTAT || '').toUpperCase() : '';
    return val.includes(me) && ps === 'DECLINED';
  });
}

function keyOf(d) { return new Date(d).toISOString().slice(0, 10); }

function isExcluded(ev, occ) {
  if (!ev.exdate) return false;
  const k = keyOf(occ);
  return Object.entries(ev.exdate).some(([key, v]) => key === k || key === occ.toISOString() || (v instanceof Date && Math.abs(v - occ) < 60000));
}

function expand(ev, dayStart, dayEnd) {
  const start = new Date(ev.start);
  const end = ev.end ? new Date(ev.end) : new Date(start.getTime() + 30 * 60000);
  const dur = end - start;
  if (!ev.rrule) return [{ ev, start, end }];
  const occs = ev.rrule.between(new Date(dayStart.getTime() - dur), dayEnd, true);
  const out = [];
  for (const raw of occs) {
    const occ = new Date(raw);
    if (isExcluded(ev, occ)) continue;
    const override = ev.recurrences && (ev.recurrences[keyOf(occ)] || ev.recurrences[occ.toISOString()]);
    if (override) continue; // overrides are handled as their own VEVENTs below
    out.push({ ev, start: occ, end: new Date(occ.getTime() + dur) });
  }
  return out;
}

async function fetchTodaysMeetings(url, myEmail) {
  url = url.replace(/^webcal:\/\//i, 'https://');
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Calendar link returned HTTP ${res.status}`);
  const data = ical.sync.parseICS(await res.text());
  const [dayStart, dayEnd] = dayBounds();
  const items = [];
  const consider = (ev) => {
    if (!ev || ev.type !== 'VEVENT') return;
    if (ev.datetype === 'date') return;                 // all-day events aren't meetings
    if (String(ev.status || '').toUpperCase() === 'CANCELLED') return;
    if (String(ev.transparency || '').toUpperCase() === 'TRANSPARENT' && !ev.attendee) return; // "free" personal blocks
    if (declined(ev, myEmail)) return;
    for (const o of expand(ev, dayStart, dayEnd)) {
      if (o.end > dayStart && o.start < dayEnd) items.push(o);
    }
  };
  for (const ev of Object.values(data)) {
    consider(ev);
    if (ev && ev.recurrences) for (const r of Object.values(ev.recurrences)) consider({ ...r, rrule: undefined, type: 'VEVENT' });
  }
  const seen = new Set();
  return items
    .map(({ ev, start, end }) => ({
      id: `${ev.uid || ev.summary}-${start.getTime()}`,
      title: (typeof ev.summary === 'object' ? ev.summary.val : ev.summary) || 'Meeting',
      start: start.toISOString(), end: end.toISOString()
    }))
    .filter((m) => (seen.has(m.id) ? false : seen.add(m.id)))
    .sort((a, b) => a.start.localeCompare(b.start));
}

module.exports = { fetchTodaysMeetings };
