// Demo mode: fast-forwards the day and fakes mail + meetings so you can see every behaviour.
const SENDERS = [['Maya', 'Moodboard v3 ✨'], ['Design Ops', 'Sprint review notes'], ['Alex', 'Quick question on the logo'], ['Figma', 'New comment on Homepage'], ['Sam', 'Lunch?'], ['Client', 'Feedback round 2']];
let timers = [], n = 0;

function start(emit) {
  stop();
  let hour = 6, emails = [], meetings = [];
  const send = () => emit({ simHour: hour, emails: [...emails], meetings: [...meetings], mailStatus: 'ok', calStatus: 'ok' });
  // a "day" every ~64s: one hour per ~4s
  timers.push(setInterval(() => { hour = (hour + 0.25) % 24; send(); }, 1000));
  // deliver a box every 5s (max 7 waiting)
  timers.push(setInterval(() => {
    if (emails.length >= 7) return;
    const [from, subject] = SENDERS[n++ % SENDERS.length];
    emails.push({ id: 'demo' + n, from, subject, date: new Date().toISOString(), url: 'https://mail.google.com/mail/u/0/#inbox' });
    send();
  }, 5000));
  // "read" the oldest box every 8s
  timers.push(setInterval(() => { if (emails.length > 1) { emails.shift(); send(); } }, 8000));
  // a meeting guest drops by for 20s every 35s
  const visit = () => {
    const now = Date.now();
    meetings = [{ id: 'demo-mtg-' + now, title: 'Design sync', start: new Date(now).toISOString(), end: new Date(now + 20000).toISOString() }];
    send();
  };
  timers.push(setTimeout(visit, 2500));
  timers.push(setInterval(visit, 35000));
  send();
}
function stop() { timers.forEach((t) => { clearInterval(t); clearTimeout(t); }); timers = []; }

module.exports = { start, stop };
