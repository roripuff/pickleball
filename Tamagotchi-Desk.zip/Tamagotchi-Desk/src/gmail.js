// Reads today's unread messages from the Gmail inbox over IMAP.
// Needs a Google "app password" (Google Account → Security → 2-Step Verification → App passwords).
const { ImapFlow } = require('imapflow');

function startOfToday() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }

function threadUrl(threadId) {
  try { return 'https://mail.google.com/mail/u/0/#all/' + BigInt(threadId).toString(16); }
  catch { return 'https://mail.google.com/mail/u/0/#inbox'; }
}

async function fetchTodaysUnread(user, pass) {
  const client = new ImapFlow({
    host: 'imap.gmail.com', port: 993, secure: true,
    auth: { user, pass }, logger: false, emitLogs: false
  });
  const today = startOfToday();
  const out = [];
  await client.connect();
  try {
    const lock = await client.getMailboxLock('INBOX');
    try {
      // IMAP SINCE is date-only; we re-filter on the exact received time below.
      const since = new Date(today.getTime() - 24 * 3600 * 1000);
      const uids = (await client.search({ seen: false, since }, { uid: true })) || [];
      if (uids.length) {
        for await (const m of client.fetch(uids, { uid: true, envelope: true, internalDate: true, threadId: true, emailId: true }, { uid: true })) {
          const received = new Date(m.internalDate || m.envelope?.date);
          if (received < today) continue;
          const f = m.envelope?.from?.[0] || {};
          out.push({
            id: String(m.emailId || m.uid),
            from: f.name || f.address || 'Someone',
            subject: m.envelope?.subject || '(no subject)',
            date: received.toISOString(),
            url: m.threadId ? threadUrl(m.threadId) : 'https://mail.google.com/mail/u/0/#inbox'
          });
        }
      }
    } finally { lock.release(); }
  } finally {
    try { await client.logout(); } catch { /* ignore */ }
  }
  out.sort((a, b) => a.date.localeCompare(b.date));
  return out;
}

module.exports = { fetchTodaysUnread };
