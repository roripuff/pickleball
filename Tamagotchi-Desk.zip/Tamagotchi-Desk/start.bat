@echo off
title Tamagotchi
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js isn't installed yet. Installing it with winget...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  echo.
  echo Node.js installed. Please close this window and double-click start.bat again.
  pause
  exit /b
)
if not exist node_modules (
  echo First run: downloading the pieces I need ^(about a minute^)...
  call npm install --no-audit --no-fund
)
if not exist "node_modules\electron\dist\electron.exe" (
  echo Finishing setup: downloading the app engine...
  call node node_modules\electron\install.js
)
start "" "node_modules\electron\dist\electron.exe" .
exit
